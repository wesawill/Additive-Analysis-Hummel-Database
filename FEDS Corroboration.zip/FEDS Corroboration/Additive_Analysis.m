function [OutputS TopTenScores] = Additive_Analysis(Pk_XVals,str_DB,tol)
%% Additive Analysis
% The purpose of this algorithm is to give a standardized qualitative
% measure of common additives in MPLs. Elucidating the content of the
% particles can help remediative and environmental toxicological research
% handle these largely unknown particles in a more eco-friendly manner. The
% FTIR databases includes entries from Hummel and myself. The Raman
% database is from Nava!
%% Peak Finding of Unknown Spectra
% format long
% swc = input("Is your unknown spectrum a collection of peaks? (Type: '1' for 'yes' or '2' for 'no'):");
% if swc == 2
%     Data = load("Plastic polymer controls\HDPE processed.csv"); %Change read according to data type (readmatrix for excel)!
%     X_unk = Data(:,1); %Change name of variable accordingly (change back to dot index structure if .mat)
%     Y_unk = 100 - Data(:,2); %Trans. to Abs.
%     [pks, locs] = findpeaks(Y_unk,NPeaks=20,SortStr="descend",MinPeakProminence=.15); %New Additions...
%     Pk_XVals = zeros(length(locs),1);
% 
%     for i = 1:length(locs)
%         Pk_XVals(i)  = X_unk(locs(i));
%     end
% elseif swc == 1
%     % plchdr = load("Additive Algorithm Code + Misc\PVC_CP.mat"); %Uncomment if you have peak values already
%     % Pk_XVals = plchdr.PVC_CP;
%     [D_2,S_2] = xlsread("FEDS Peaks.xlsx");
%     Pk_XVals = D_2(:,6); %Change column for your peaks of choice...
% else 
%     disp("Input error therefore premature termination was executed.")
%     return
% end
%% Upload of DB (FTIR/Raman)
% DB = readmatrix("Additive and Pigment Study\Wave Numbers of Common Plastic Additives.xlsx")
% [D,S] = xlsread("RamanPolymers.xlsx"); %Commented for Current Version (YPD/10-10-24)...
format long
[D,S] = xlsread(str_DB);
D(isnan(D)) = 0; %turns all NaN to zero entries
D = max(D,0); %All negative entries are zero entries to avoid neg. minima being labeled as peaks
% NP = input("Is your database a collection of peaks, not spectra? (Type:
% '1' for 'yes' or '2' for 'No'):"); %Commented for Current Version (YPD/10-10-24)...
NP = 2;

if NP == 1
    D_x = D(:,1);
    for i = 1:length(D(1,:))-1
        [pks, locs] = findpeaks(D(:,i+1),NPeaks=20,SortStr="descend");
        for j = 1:length(locs)
            E(j,i+1) = D_x(locs(j));
        end
    end
    E(:,1) = [];
    D = E;
    D = sort(D,"ascend");
    S(:,1) = [];
    l = length(S(:,1));
    S(2:l,:) = []; 
% else
%     disp("Input error therefore premature termination was executed.")
%     return
end
%% Qualitative Estimation
k = 1;
h = 0; %number of hits on a given DB entry with respect to unknown peaks
dif_norm = zeros(length(Pk_XVals),1); %In case there is no match within the calculations...
ZeroPH = zeros(100,1); %creating variable with arbitrary dimension for conditional statement before assignment
% tol = input("What is your set tolerance (1/cm)?:"); %Commented for Current Version (YPD/10-10-24)...
for i = 1:length(D(1,:)) %for length of columns (aka entries)
    for j = 1:length(D(:,i))
        if D(j,i) == 0 || j == length(D(1,:)) %choosing length end condition based on no zero entries
            if NP == 1
                for k = 1:length(Pk_XVals) %scanning for peak matches in DB entry one unknown peak at a time
                    if Pk_XVals(k) >= search_range(1) && Pk_XVals(k) <= search_range(2)
                        if Pk_XVals(k) == D(j,i)
                            ZeroPH(k) = k; %Helps overwrite non matches as perfect match under this condition                   
                        end
                    dif = abs(D(j,i) - Pk_XVals(k));
                    dif_norm(k,1) = dif/tol;
                    h = h + 1; %hit in DB entry            
                    elseif (Pk_XVals(k) - D(j,i)) >= 50 %limits excessive iterating
                        break
                    else
                        continue
                    end
                end
            end
            h_tot = length(Pk_XVals);
            frac_scalar(i,1) = h/h_tot;
            dif_norm(dif_norm==0) = 15; %Setting max tolerance for zero
            for m = 1:length(dif_norm) %entries equating to worst peak matches (DEBUG POSTERITY)
                if ZeroPH(m) ~= 0
                    dif_norm(m) = 0; %overwrites non-match placeholder as perfect match
                end
            end
            
            SimScore(i,:) = (1/(mean(dif_norm))^2)*frac_scalar(i,1); %the smaller the dif the better
            h = 0; %Reinitialize components of score
            dif_norm = 0;
            ZeroPH = zeros(100,1);
            break
        end
        search_range = [D(j,i) - tol, D(j,i) + tol];
       
        for k = 1:length(Pk_XVals) %scanning for peak matches in DB entry one unknown peak at a time
            if Pk_XVals(k) >= search_range(1) && Pk_XVals(k) <= search_range(2)
                if Pk_XVals(k) == D(j,i)
                    ZeroPH(k) = k; %Helps overwrite non-matches as perfect match under this condition                   
                end
                dif = abs(D(j,i) - Pk_XVals(k));
                dif_norm(k,1) = dif/tol;
                h = h + 1; %hit in DB entry            
            elseif (Pk_XVals(k) - D(j,i)) >= 50 %limits excessive iterating
                break
            else
                continue
            end
        end
    end
end
%% Score Attribution
SimScoreSort = sort(SimScore,'descend');
SimScoreSort(isnan(SimScoreSort)) = []; %Removed NaN values
TopTenScores = SimScoreSort(1:10);
TopTenScores(isinf(TopTenScores)) = []; %Removes Inf (meaning 0 entry) %2 new lines
TopTenScores = TopTenScores(TopTenScores~=0); %Removes 0 score

i = 2;
x = 1; %random value to keep the loop going
y = 1;
j = 2; %separate iterator for counting duplicates
b = 0; %duplicate counter
c = 0; %value of excess iterations from calculating duplicates
e = 0; %placeholder for score skipped
m = 1; %reorients for duplicate at top of array
while x == 1
    if i > length(TopTenScores) + c %Aids in terminating the loop
        break
    else
        while y == 1
            if j - 1 == length(TopTenScores)
                break
            else
                if TopTenScores(j) == TopTenScores(j-1)
                    b = b + 1;
                    j = j + 1;
                else
                    j = j + 1;
                    break
                end
            end
        end
            if TopTenScores(i) == TopTenScores(i-1) %This handles duplicate scores where one pulls 2 locations in the DB. ADJUST IF MORE THAN 2!
                TopTenPositions(i-1:i+b-1) = find(SimScore==TopTenScores(i-1));
                OutputS(i-1:i+b-1) = S(1,TopTenPositions(i-1:i+b-1));
                i = i + 1 + b;
                b = 0; %reinitializing for next duplicate grouping, if any
                % if NP == 1
                %    OutputS(i-1:i+b-1) = S(1,TopTenPositions(i-1:i+b-1)); %Raman DB has no title in header matrix
                %    i = i + 1 + b;
                %    b = 0; %reinitializing for next duplicate grouping, if any
                % else
                %     OutputS(i-1:i+b-1) = S(2,TopTenPositions(i-1:i+b-1));
                %     i = i + 1 + b;
                %     b = 0; %reinitializing for next duplicate grouping, if any
                % end

                %Commented for Use of DB with Double header (title/entries)
                
                
            else
                TopTenPositions(i-1) = find(SimScore==TopTenScores(i-1));
                if NP == 1||2
                    OutputS(i-1) = S(1,TopTenPositions(i-1));
                    i = i + 1;
                % else
                %     OutputS(i-1) = S(1,TopTenPositions(i-1)); %Change back to "2,TopTen..."
                %     i = i + 1;
                end
                
                if length(TopTenPositions) == length(TopTenScores)
                    break
                end
            end
            
    end 
end

if length(OutputS) ~= length(TopTenScores) %This means that the duplicate wasn't a part of the final value/updated to include entries with less than 10 DB entries
    TopTenPositions(i-1) = 0; %Placeholder for array
    Z = find(SimScore==TopTenScores(i-1)); %holds tenth or tenth, eleventh, etc. score
    TopTenPositions(i-1) = Z(1); %Final Step
    if NP == 1||2 %Delete or...
        OutputS(i-1) = S(1,TopTenPositions(i-1));
    % else
    %     OutputS(i-1) = S(2,TopTenPositions(i-1)); %Uncomment
    end
    
end

% disp(S_2(6)) %CHANGE _ Displays names
% disp("Top 10 Hits in Chosen DB and their scores:")
% for i = 1:length(OutputS)
%     Ranking = [i;cell2mat(OutputS(i));"Score:";TopTenScores(i)];
%     disp(Ranking)
% end

OutputS = OutputS';
end