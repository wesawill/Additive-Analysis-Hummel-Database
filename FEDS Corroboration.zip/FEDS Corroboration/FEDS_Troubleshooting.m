function PkWns = FEDS_Troubleshooting(X,Y)  
%% FEDS Demo (Palencia, 2018)
% T = readtable("Unk63.xlsx");
% X = T.wavenumber;
% Y = T.intensity; % Norm. Abs or "aN"
% k = find(Y == 0);
% Y(k) = 1E-5; %Replaces 0 with arb value to avoid "inf" calc for the derivative...

Yinv = Y.^-1;
k = find(Yinv == Inf);
Yinv(k) = 0;

for i = 1:length(X)-1
    dAinv_dv(i) = Yinv(i+1)-(Yinv(i));
end

p = dAinv_dv;
p = [p 0]; %placeholder
p = abs(p);
m = max(p);

P = (1+Y)./(sqrt(p'));

k2 = find(P == Inf);
P(k2) = 0;
% plot(X,Y,X,P) No need for plot during function call!!!
% title("FEDS Transform on Unk63") %Change
% xlabel("Wavenumber (1/cm)")
% ylabel("Relative Intensity")
% legend("Unk63","FEDS") %Change

%% Find Peaks
Transform = [X P];
[pks locs] = findpeaks(Transform(:,2),NPeaks=20); %Consistent # for main YPD Script
PkWns = X(locs);
if length(locs) <20 %Makes size consistent
    Num = 20 - length(locs);
    for k = 1:Num
        PkWns = [PkWns; 0];
    end
end
