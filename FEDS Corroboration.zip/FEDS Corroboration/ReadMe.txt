The main script for the FEDS Corroboration is the "YPD_Validation" script.

Here, the code is seperated into 3 bodies. The first finds peaks within spectroscopic biological samples from the Miller dataset. The second does the same for the unknown peaks captured in our lab. After manual addition of the peaks to a set of polymer standards, we load them into the workspace to feed them through an algorithm that can find matches for unknowns based on a reference databases. This is the Additive_Algorithm though it has been retrofitted for the purposes of this study.

The results is a matrix of labels and scores for comparison for each unknown entry.