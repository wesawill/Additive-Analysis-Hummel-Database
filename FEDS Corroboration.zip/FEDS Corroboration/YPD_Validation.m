%% YPD Validation
%This Code is designed to retrofit older scripts to output a
%semi-quantitativeanalysis of the unknowns. First, the code will gather the
%reference database, notation of the databases being a colleciton of peaks
%or just the spectra, and the sample (master csv). The output shpuld be a
%10x#ofUnknows where both the CNN and OS can be validated (in excel) thus measuring
%the validity of both!
%% Peak Values Extracted from Biological Reference
Data = readmatrix("MillerBIOL_Proc_Res8Baseline4Trun200to2000MinMaxNorm.csv"); %Miller is in order!
Data = Data(1:numel(Data(:,1)),1:226); %Metadata excision
Data = transpose(Data);
X = Data(:,1);
z = length(Data(1,:)) - 1;
pval = zeros(20,z);

for i = 2:length(Data(1,:))
    [pks locs] = findpeaks(Data(:,i),NPeaks=20,SortStr="descend");
    for j = 1:length(locs)
        pval(j,i-1) = X(locs(j)); %int overwrite for locs
    end
end
pval = sort(pval); %least to greatest wavenumber
%Append peak values, with labels, onto RamanPolymers in excel...Apply combined
%reference database to Additive_Analysis.m as a function!
%% Call FEDS Script for Each Unknown
Data2 = readmatrix("UnknownMPMASTER.csv");
Data2 = Data2(1:numel(Data2(:,1)),1:226); %Metadata excision
Data2 = transpose(Data2);
X = 0; %Overwrite
X = Data2(:,1);
z2 = length(Data2(1,:)) -1;
UnkPksFEDS = zeros(20,z2);

for i = 2:length(Data2(1,:))
    Y = Data2(:,i);
    UnkPksFEDS(:,i-1) = FEDS_Troubleshooting(X,Y); %Calling FEDS Transform
end
%Save FEDS-transformed Unknowns (they are in order from Unk1 to Unk149)
%% Call Additive_Algorithm w/ Reference and Unknown Data ('peaks' form)
%Be sure to gather "S" matrix for ALL reference entries as well as "Score"
%Inputs should either be in .mat format or strings of files in the local
%folder, whichever is simplest and avoids major retrofitting of the
%original AA script!
clear all
clc

str_DB = "RamanPolymers_MillerBIOL.xlsx"; %Used to call database within function.
load("UnknowMPFEDSPeaks.mat") %loads unknowns
MasterOutS = zeros(10,length(UnkPksFEDS));
MasterTTS = zeros(10,length(UnkPksFEDS));
MasterOutS = num2cell(MasterOutS); %Cell output from function
tol = 5; %Tolerance set outside of function

for i = 1:length(UnkPksFEDS(1,:))
    Pk_XVals = UnkPksFEDS(:,i);
    Pk_XVals = Pk_XVals(Pk_XVals~=0); %Retains nonzero elements
    [OutputS TopTenScores] = Additive_Analysis(Pk_XVals,str_DB,tol) % Tolerance set as 5 1/cm!
    if length(OutputS) ~= 10
        num = 10 - length(OutputS);
        for j = 1:num
            OutputS = [OutputS; {'Null'}];
            TopTenScores = [TopTenScores; 0];
        end
    end
    MasterOutS(:,i) = OutputS; %Original output for posterity
    MasterTTS(:,i) = TopTenScores;
end

MOS_ExcCharc = MasterOutS;
MTTS_ExcCharc = MasterTTS;
for k = 1:149
    for m = 1:10
        if strcmp(MOS_ExcCharc{m,k},'BIOL002_Charcoal') == 1
            MOS_ExcCharc{m,k} = []; %Removal due to visual check (No particle is black like charcoal)...
            MTTS_ExcCharc(m,k) = 0; %Removal of corresponding score
        end
    end
end