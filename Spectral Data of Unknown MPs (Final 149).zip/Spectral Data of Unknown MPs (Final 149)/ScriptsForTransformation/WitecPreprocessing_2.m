%%Search for File Pairs, BG Subtract, then Convert to .csv for OS
%%Processing
load("FileListIndex.mat")
j = 2;
for i = 1:((length(FileListIndex)/2)-1)
    idx = string(FileListIndex(j));
    idx = erase(idx, '(Y-Axis).txt');
    idx = append(idx,'.txt');
    Tf_1 = readtable(idx);
    Ty_1 = Tf_1.Var2;
    idx = string(FileListIndex(j+2));
    idx = erase(idx, '(Y-Axis).txt');
    idx = append(idx,'.txt');
    Tf_2 = readtable(idx);
    Ty_2 = Tf_2.Var2;
    Ty_f = Ty_1 - Ty_2; %Background Sub
    Tx = Tf_1.Var1;
    Tf = [Tx Ty_f];
    header = {'wavelength' 'intensity'};
    Tf = [header; num2cell(Tf)];
    idx = erase(idx,' .txt');
    idx = erase(idx,'BG');
    idx = append(idx,'.csv');
    filename =  idx; % second entry was num2str(i) for y in abs
    writecell(Tf,filename)
    j = j + 2;
end