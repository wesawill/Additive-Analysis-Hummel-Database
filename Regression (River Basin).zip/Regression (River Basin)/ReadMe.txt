The main script serving to perform the regressions, aside from GPTIPS, is "InterpolationCNN_OS".

Surface plots, coefficients, and matrices of the predictions (errors/y_hat) were generated and labeled accordingly as well as RMSE and gene (node) weight for each run (OS/CNN). Expressions should be self-explantory.