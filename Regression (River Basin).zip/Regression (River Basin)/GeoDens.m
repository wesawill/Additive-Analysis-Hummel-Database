T = readtable("GeoBubbleData.xlsx");
lat = T.Lat;
lon = T.Long;
sz = T.W2; %Change
cd = T.Type;
cd = categorical(cd);

gb = geobubble(lat,lon,sz,cd);
geobasemap("streets")
geolimits([33. 36.75],[-82 -79])
gb.Title = "OS Relative Abundance (MPL/MP)";
gb.SizeLegendTitle = "Magnitude";
gb.ColorLegendTitle = "Test Type";
