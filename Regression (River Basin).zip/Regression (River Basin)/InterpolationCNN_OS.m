%% Generates interpolated data...
swc = 2; %off
if swc == 1 
    x = [925.25; 724.25; 632.75]; %Mean Altitude (ft.)
    y = [607.07; 1665.91; 1256.15]; %Mean Population Desnsity (sq. mi. -2)
    v_CNN = [.1667;.333375;.208425]; %Rel. MPL Conc.
    v_OS = [.104175;.093775;.072925];
    dummy = [1;2;3];

    x_spline = spline(dummy,x,linspace(1,3,20));
    y_spline = spline(dummy,y,linspace(1,3,20));
    vq_CNN = scatteredInterpolant(x,y,v_CNN,"linear","linear");
    vq_OS = scatteredInterpolant(x,y,v_OS,"linear","linear");
    CNN_int = vq_CNN(x_spline,y_spline);
    OS_int = vq_OS(x_spline,y_spline);

    CNN_Mat = [x_spline' y_spline' CNN_int'];
    OS_Mat = [x_spline' y_spline' OS_int'];


    % if cubic == 1
    %     v_OS = [0.013261; 0.012311; 0.012311-(1E-20)];
    % end
    %
    %
    % if cubic == 1
    %     vq_CNN1 = linspace(0.028653,0.041669,10);
    %     vq_CNN2 = linspace(0.041669,0.016931,10);
    %     vq_OS1 = linspace(0.013261,.012311,10);
    %     vq_OS2 = linspace(0.012311,0.012311-(1E-20),10);
    %
    %       % s = 1; %alternating sign as to not deviate too much
    %       % for i = 1:10
    %       %     vq_OS2(i) = vq_OS2(i) + s*(1E-10); %Arbitrary negligible factor (ensures cubic spline can run)
    %       %     s = -1*s;
    %       % end
    %
    %     vq_CNN = [vq_CNN1 vq_CNN2];
    %     vq_OS = [vq_OS1 vq_OS2];
    %     xqc_CNN = spline(v_CNN,x,vq_CNN);
    %     xqc_OS = spline(v_OS,x,vq_OS); %spline doesn't work for non-unique values
    %     yqc_CNN = spline(v_CNN,y,vq_CNN);
    %     yqc_OS = spline(v_OS,y,vq_OS);
    %
    %     xqc_OS = [xqc_OS linspace(724.25,632.75,10)]; %%) START HERE... find alternative way for OS...
    %     yqc_OS = [yqc_OS linspace(1665.91,1256.15,10)];
    %
    %     vqc_CNNInter = scatteredInterpolant(x,y,v_CNN,"linear","linear");
    %     vqc_CNN = vqc_CNNInter(xqc_CNN,yqc_CNN);
    %     vqc_OSInter = scatteredInterpolant(x,y,v_OS,"linear","linear");
    %     vqc_OS = vqc_OSInter(xqc_OS,yqc_OS);
    %     CNN_Cubic = [xqc_CNN' yqc_CNN' vqc_CNN'];
    %     OS_Cubic = [xqc_OS' yqc_OS' vqc_OS'];
    % else %Adapt for BOTH cases later...!!!!!!!
    %     yq = [yq_1 yq_2];
    %     xq_1 = linspace(925.25,724.25,10); %Mirroring division for y
    %     xq_2 = linspace(724.25,632.75,10);
    %     xq = [xq_1 xq_2];
    %     yq_1 = linspace(607.07,1665.91,10); %Dividing space in 2 due to sign change
    %     yq_2 = linspace(1665.91,1256.15,10);
    %     yq = [yq_1 yq_2];
    %
    %
    %
    %     vq_OS = scatteredInterpolant(x,y,v_OS,"linear","linear");
    %     vq = vq_OS(xq,yq);
    % end
    % NOTES: Remove cubic attempt and place elsewhere...
end
%% Multiple Linear Regression
if swc == 1
    load("OS_Mat.mat"); % Load appropriate matrix of interpolated x, y, and v
    X= [ones(size(OS_Mat(:,1))) OS_Mat(:,1) OS_Mat(:,2) OS_Mat(:,1).*OS_Mat(:,2)];
    b_OS = regress(OS_Mat(:,3),X);

    scatter3(OS_Mat(:,1),OS_Mat(:,2),OS_Mat(:,3),'filled');
    hold on
    x1fit = min(OS_Mat(:,1)):100:max(OS_Mat(:,1));
    x2fit = min(OS_Mat(:,2)):10:max(OS_Mat(:,2));
    [X1FIT,X2FIT] = meshgrid(x1fit,x2fit);
    YFIT = b_OS(1) + b_OS(2)*X1FIT + b_OS(3)*X2FIT + b_OS(4)*X1FIT.*X2FIT;
    mesh(X1FIT,X2FIT,YFIT)
    title("Multiple Linear Regression (CNN)")
    xlabel('Mean Altitude (ft.)')
    ylabel('Population Density (sq.mi.^-2)')
    zlabel("Relative MPL Concentration % (MPL/MP)")
    view(50,10)
    hold off
end
%% Multiple Polynomial Regression
if swc == 1
    % Testing "poly23" and "poly45" due to even and odd behavior of altitude
    % and population density...
    load("OS_Mat.mat");
    fitsurface = fit([OS_Mat(:,1),OS_Mat(:,2)],OS_Mat(:,3),'poly23')
    plot(fitsurface,[OS_Mat(:,1),OS_Mat(:,2)],OS_Mat(:,3))
    title("Multiple Polynomial Regression (OS)");
    xlabel('Mean Altitude (ft.)')
    ylabel('Population Density (1/sq.mi.)')
    zlabel("Relative MPL Concentration % (MPL/MP)")
end

%% Genetic Program (Symbolic Algorithm)
if swc == 1
    load("OS_Mat.mat")
    scatter3(OS_Mat(:,1),OS_Mat(:,2),OS_Mat(:,3),'filled');
    hold on
    x1fit = min(OS_Mat(:,1)):100:max(OS_Mat(:,1));
    x2fit = min(OS_Mat(:,2)):10:max(OS_Mat(:,2));
    [X1FIT,X2FIT] = meshgrid(x1fit,x2fit);
    YFIT_1 = (.0001469)*X1FIT + (1.807E-5)*X2FIT - .04275; %plug in coeff from GPTIPS
    mesh(X1FIT,X2FIT,YFIT_1)
    title("GPTIPS (OS)")
    xlabel('Mean Altitude (ft.)')
    ylabel('Population Density (sq.mi.-2)')
    zlabel("Relative MPL Concentration % (MPL/MP)")
    view(50,10)
    hold off
end
%% Predicted Values of Area 1, 2, and 3
fCNN = @(x1,x2) -0.300400541507622 + 0.000357081584476058.*x1 + 0.000225197762154495.*x2 + 3.41359994773496e-20.*x1.*x2;
fOS = @(x1,x2) -0.0427517713598803 + 0.000146939813647887.*x1 + 1.80715712886038e-05.*x2 + 6.00985906291366e-23.*x1.*x2;
fCNN2 = @(x1,x2) -0.6618 + 0.001285.*x1 +  0.0006036.*x2 + -5.645e-07.*x1.^2 + -9.071e-07.*x1.*x2 + -5.433e-08.*x2.^2 + 5.008e-10.*x1.^2.*x2 + 7.469e-11.*x1.*x2.^2 + 2.784e-12.*x2.^3;
fOS2 = @(x1,x2) -0.07078 +  0.0002188.*x1 +  5.691e-05.*x2 +  -4.377e-08.*x1.^2 + -9.469e-08.*x1.*x2 + -5.728e-09.*x2.^2 +  5.366e-11 .*x1.^2.*x2 +  8.002e-12.*x1.*x2.^2 +  2.983e-13.*x2.^3;
fCNN3 = @(x1,x2) .0003571.*x1 + .0002252.*x2 - .3004;
fOS3 = @(x1,x2) .0001469.*x1 - 1.807e-5.*x2 - .04275;
load("CNN_Mat.mat")
load("OS_Mat.mat")

fCNNpred = [fCNN(CNN_Mat(:,1),CNN_Mat(:,2)) fCNN2(CNN_Mat(:,1),CNN_Mat(:,2)) fCNN3(CNN_Mat(:,1),CNN_Mat(:,2))];
fOSpred = [fOS(OS_Mat(:,1),OS_Mat(:,2)) fOS2(OS_Mat(:,1),OS_Mat(:,2)) fOS3(OS_Mat(:,1),OS_Mat(:,2))];
ErrorCNN = abs(fCNNpred - CNN_Mat(:,3));
ErrorOS = abs(fOSpred - OS_Mat(:,3));

%Basin Analysis

CityMat = [1102 911.15; % Mt. Airy, NC
            1043 573.76; % Wilkesboro, NC
            896	1122.17; % Statesville, Nc
            856	759.53; % Mocksville, NC
            516	928.05; % Albemarle, NC
            696	2821.06; % Charlotte, NC
            143	1705.45; % Florence, SC
            171	1322.59; % Sumter, SC
            20 1201.80;]; % Georgetown, SC
CNNCityPred = [fCNN(CityMat(:,1),CityMat(:,2)) fCNN2(CityMat(:,1),CityMat(:,2)) fCNN3(CityMat(:,1),CityMat(:,2))];
OSCityPred = [fOS(CityMat(:,1),CityMat(:,2)) fOS2(CityMat(:,1),CityMat(:,2)) fOS3(CityMat(:,1),CityMat(:,2))];