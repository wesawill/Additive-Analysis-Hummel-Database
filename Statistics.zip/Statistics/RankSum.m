j = 1;
for i = 1:8
    [p(i), h(i), stats(i)] = ranksum(M(j,:),M(j+1,:));
    j = j + 2;
end