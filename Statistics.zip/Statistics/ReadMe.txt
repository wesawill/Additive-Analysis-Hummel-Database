Mann-Whitney U was carried out using MATLAB's built in function "ranksum" in script "Ranksum"

Accuracies were organized in the follwoing two matrices to determine effects of different training datasets from version to version. 2 sets of p-values and test statistics were generated.