Raw softmax scores fo V2 are within the .mat files in "NN workspace"
Labeled predictions can be generated with "TestingDSClassification.m"