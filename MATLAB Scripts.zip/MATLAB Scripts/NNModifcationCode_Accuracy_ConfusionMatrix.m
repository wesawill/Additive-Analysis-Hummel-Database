%%TrainNet
imds = imageDatastore("Version 2 Data/Version 2 - 7200 TrainingDS/Version 2 - 7200 TrainingDS/Raman/",IncludeSubfolders=true,LabelSource="foldernames");
classNames = categories(imds.Labels); %gathers class names for verification
numClasses = numel(classNames); %Verifies correct number of classes

[imdsTrain,imdsValidation,imdsTest] = splitEachLabel(imds,0.6,0.3,"randomized"); %splits data into given rati for training, validation, and testing.
net = imagePretrainedNetwork("resnet18",NumClasses=numClasses); %First argument can be any pretrained network specified in the email notes!!!

inputSize = net.Layers(1).InputSize;

% net = setLearnRateFactor(net,"conv10/Weights",10);
% net = setLearnRateFactor(net,"conv10/Bias",10);

augimdsTrain = augmentedImageDatastore(inputSize(1:2),imdsTrain);
augimdsValidation = augmentedImageDatastore(inputSize(1:2),imdsValidation);
augimdsTest = augmentedImageDatastore(inputSize(1:2),imdsTest);

options = trainingOptions("adam", ...
MaxEpochs=10, ...
MiniBatchSize=32, ...
InitialLearnRate=0.0011, ...
ValidationData=augimdsValidation, ...
ValidationFrequency=5, ...
Plots="training-progress", ...
Metrics="accuracy", ...
Verbose=false);

net_2 = trainnet(augimdsTrain,net,"crossentropy",options);
YTest = minibatchpredict(net_2,augimdsTest);
YTestLabels = scores2label(YTest,classNames);
TTest = imdsTest.Labels;
acc = mean(TTest==YTestLabels);
disp(acc)
plotconfusion(TTest,YTestLabels)

%Test Primpke
imds_ext = imageDatastore("DongMillerRaman_Pic/",IncludeSubfolders=true,LabelSource="foldernames");
auds_ext = augmentedImageDatastore(inputSize(1:2),imds_ext);
YTest_ext = minibatchpredict(net_2,auds_ext);
disp(YTest_ext)