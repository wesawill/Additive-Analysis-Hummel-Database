swc = input('Does the spectra need rescaling (1: Yes, 2: No)?');

B = readmatrix("Dong_MillerMasterCSV.csv");
B = B(1:numel(B(:,1)),1:222); %Excising metadata (ADJUST AS NECESSARY)
B = transpose(B); %row to column-wise organization
if swc == 1
    for i = 1:(numel(B(1,:))-1)
        B(:,1+i) = rescale(B(:,1+i));
    end
end
B = flip(B);

for i = 1:(numel(B(1,:))-1)
    plot(B(:,1),B(:,i+1))
    filenum = ['Dong_Miller',num2str(i),'.png'];
    xlim([224 1992])
    ylim([0 1])
    yticks([0 0.2 0.4 0.6 0.8 1])
    yticklabels({0 0.2 0.4 0.6 0.8 1})
    ax = gca;
    exportgraphics(ax,filenum)
end