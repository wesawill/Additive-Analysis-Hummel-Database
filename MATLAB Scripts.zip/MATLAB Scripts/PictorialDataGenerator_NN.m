filenum = input('How many synthetic spectra is needed?:');
swc = input('Does the spectra need rescaling (1: Yes, 2: No)?');

B = readmatrix("PE_FLOPPEMaster.csv");
B = B(1:numel(B(:,1)),1:416); %Excising metadata (ADJUST AS NECESSARY)
B = transpose(B); %row to column-wise organization
if swc == 1
    for i = 1:(numel(B(1,:))-1)
        B(:,1+i) = rescale(B(:,1+i));
    end
end
l_files = numel(B(1,:)) - 1;

C = zeros(length(B(:,1)),l_files);
D = zeros(length(B(:,1)),filenum);
r = rand(1,l_files);
r = r/sum(r);
l = 2;
    
for n = 1:filenum
    for i = 1:l_files
        C(:,i) = B(:,l)*r(i);
        l = l + 1;
    end
    D(:,n) = sum(C,2); %New spectra
    r = rand(1,l_files);
    r = r/sum(r);
    l = 2;
    disp(n)
end
D = [B(:,1) D];

for i = 1:filenum
    plot(D(:,1),D(:,i+1))
    filenum = ['EXAMPLE',num2str(i+300),'.png'];
    xlim([680 4000])
    ylim([0 1])
    yticks([0 0.2 0.4 0.6 0.8 1])
    yticklabels({0 0.2 0.4 0.6 0.8 1})
    ax = gca;
    exportgraphics(ax,filenum)
end