%%Classification
%This script generates an array of strings, labels, of MPL predictions
%based on the position of the maximum score (columnar).
%%
% load("V2 Data\M24_V2.mat")
Maximums = max(YTest_ext,[],2);
LPred = length(YTest_ext(:,1));
Pred = cell(LPred,1);
for i = 1:length(YTest_ext(:,1))
    [row(i) col(i)] = find(YTest_ext(i,:)==Maximums(i));
    if col(i) == 1
        Pred(i) = {"CA"};
    elseif col(i) == 2
        Pred(i) = {"HDPE"};
    elseif col(i) == 3
        Pred(i) = {"LDPE"};
    elseif col(i) == 4
        Pred(i) = {"PA"};
    elseif col(i) == 5
        Pred(i) = {"PET"};
    elseif col(i) == 6
        Pred(i) = {"PMMA"};
    elseif col(i) == 7
        Pred(i) = {"PP"};
    elseif col(i) == 8
        Pred(i) = {"PS"};
    elseif col(i) == 9
        Pred(i) = {"PVC"};
    end
end
